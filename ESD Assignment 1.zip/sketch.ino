const int GAS_SENSOR_PIN = 34;
const int BUZZER_PIN = 2;       

const int GAS_THRESHOLD = 1500; 

int currentGasLevel = 0;        
bool isAlarmActive = false;     

void setup() {
    Serial.begin(115200);
  
  pinMode(BUZZER_PIN, OUTPUT);
  
  digitalWrite(BUZZER_PIN, HIGH);
  
  Serial.println(" Gas Leakage Detector System Initialized");
  Serial.print(" Alarm Trigger Threshold: ");
  Serial.println(GAS_THRESHOLD);
  Serial.println(" Monitoring for gas leaks...");
  
  delay(2000); 
}

void loop() {
  currentGasLevel = analogRead(GAS_SENSOR_PIN);
  
  if (currentGasLevel > GAS_THRESHOLD) {
    if (!isAlarmActive) {
      isAlarmActive = true;
      Serial.println(" *** ALARM TRIGGERED! Gas leak detected! *** ");
    }
    digitalWrite(BUZZER_PIN, HIGH); 
  } 
  else {
    if (isAlarmActive) {
      isAlarmActive = false;
      Serial.println(" --- Gas levels normal. Alarm cleared. --- ");
    }
    digitalWrite(BUZZER_PIN, LOW);
  }
  
  Serial.print("Gas Level: ");
  Serial.print(currentGasLevel);
  Serial.print(" | Status: ");
  if (isAlarmActive) {
    Serial.println("ALERT");
  } else {
    Serial.println("SAFE");
  }
  
  delay(500);
}