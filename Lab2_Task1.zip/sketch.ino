#define Exhaust_Fan 21
#define Bathroom_Light 2

unsigned long delayStartTime = 0;
const unsigned long fanDelay = 10000;
bool timeRunning = false;

void setup(){
  pinMode(Bathroom_Light, INPUT);
  pinMode(Exhaust_Fan, OUTPUT);
  digitalWrite(Exhaust_Fan, LOW);
}

void loop(){
  int lightState = digitalRead(Bathroom_Light);

  if (lightState == HIGH){
    digitalWrite(Exhaust_Fan, HIGH);
    timeRunning = false;
  }
  else{
    if (!timeRunning && digitalRead(Exhaust_Fan) == HIGH){
      delayStartTime = millis();
      timeRunning = true;
    }
    if (timeRunning){
      if (millis() - delayStartTime >= fanDelay){
        digitalWrite(Exhaust_Fan, LOW);
        timeRunning = false;
      }
    }
  }
}