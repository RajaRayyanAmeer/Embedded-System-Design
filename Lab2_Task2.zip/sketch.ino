#define LEVEL_SENSOR 15
#define MANUAL_BUTTON 4
#define PUMP_PIN 21
#define STATUS_LED 22

bool pumpState = false;

void setup() {
  pinMode(LEVEL_SENSOR, INPUT_PULLUP);
  pinMode(MANUAL_BUTTON, INPUT_PULLUP);
  pinMode(PUMP_PIN, OUTPUT);
  pinMode(STATUS_LED, OUTPUT);

  digitalWrite(PUMP_PIN, LOW);
  digitalWrite(STATUS_LED, LOW);
}

void loop() {

  bool tankFull = (digitalRead(LEVEL_SENSOR) == LOW);
  bool manualPressed = (digitalRead(MANUAL_BUTTON) == LOW);

  if (tankFull) {
    pumpState = false;
  }

  else {
    if (manualPressed) {
      pumpState = true;
    }
  }

  digitalWrite(PUMP_PIN, pumpState);
  digitalWrite(STATUS_LED, pumpState);
}