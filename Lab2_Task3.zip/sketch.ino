#define DOOR_SENSOR 21
#define LIGHT_PIN   15

unsigned long closeStartTime = 0;
const unsigned long lightDelay = 2000;

bool timerRunning = false;

void setup() {
  pinMode(DOOR_SENSOR, INPUT_PULLUP);
  pinMode(LIGHT_PIN, OUTPUT);
  digitalWrite(LIGHT_PIN, LOW);
}

void loop() {
  bool doorOpen = (digitalRead(DOOR_SENSOR) == LOW);

  if (doorOpen) {
    digitalWrite(LIGHT_PIN, HIGH);
    timerRunning = false;   
  }

  else {
    if (!timerRunning && digitalRead(LIGHT_PIN) == HIGH) {
      closeStartTime = millis();
      timerRunning = true;
    }

    if (timerRunning) {
      if (millis() - closeStartTime >= lightDelay) {
        digitalWrite(LIGHT_PIN, LOW);
        timerRunning = false;
      }
    }
  }
}