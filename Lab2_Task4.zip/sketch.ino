#define DOOR_SENSOR 33
#define BUZZER_PIN 23
#define STATUS_LED 22

void setup() {
  pinMode(DOOR_SENSOR, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(STATUS_LED, OUTPUT);

  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(STATUS_LED, LOW);
}

void loop() {

  bool doorOpen = (digitalRead(DOOR_SENSOR) == LOW);

  if (doorOpen) {
    digitalWrite(BUZZER_PIN, HIGH);
    digitalWrite(STATUS_LED, HIGH);
  } 
  else {
    digitalWrite(BUZZER_PIN, LOW);
    digitalWrite(STATUS_LED, LOW);
  }
}