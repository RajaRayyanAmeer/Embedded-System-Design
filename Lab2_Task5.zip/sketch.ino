#define N_RED    13
#define N_GREEN  12

#define E_RED    14
#define E_GREEN  27

#define S_RED    26
#define S_GREEN  25

#define W_RED    33
#define W_GREEN  32

const unsigned long greenTime = 2000; 
unsigned long previousMillis = 0;

int currentState = 0;

void setup() {
  int pins[] = {N_RED,N_GREEN,E_RED,E_GREEN,S_RED,S_GREEN,W_RED,W_GREEN};
  for(int i=0;i<8;i++)
    pinMode(pins[i], OUTPUT);
  setAllRed();
}

void loop() {
  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= greenTime) {
    previousMillis = currentMillis;
    currentState = (currentState + 1) % 4;
  }
  updateTrafficLights(currentState);
}

void setAllRed() {
  digitalWrite(N_RED, HIGH);
  digitalWrite(E_RED, HIGH);
  digitalWrite(S_RED, HIGH);
  digitalWrite(W_RED, HIGH);
  digitalWrite(N_GREEN, LOW);
  digitalWrite(E_GREEN, LOW);
  digitalWrite(S_GREEN, LOW);
  digitalWrite(W_GREEN, LOW);
}

void updateTrafficLights(int state) {
  setAllRed(); 
  switch(state) {
    case 0:  
      digitalWrite(N_RED, LOW);
      digitalWrite(N_GREEN, HIGH);
      break;
    case 1:  
      digitalWrite(E_RED, LOW);
      digitalWrite(E_GREEN, HIGH);
      break;
    case 2: 
      digitalWrite(S_RED, LOW);
      digitalWrite(S_GREEN, HIGH);
      break;
    case 3: 
      digitalWrite(W_RED, LOW);
      digitalWrite(W_GREEN, HIGH);
      break;
  }
}