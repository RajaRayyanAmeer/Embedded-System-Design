from machine import Pin, ADC, PWM
import time

# GPIO Pin Definitions
TEMP_SENSOR_PIN = 34

# OUTPUTS (using LEDs instead of fan/motor)
FAN_LED_PIN = 18      # LED to simulate fan (green or blue recommended)
BUZZER_PIN = 19
LED_GREEN = 13        # Normal temp indicator
LED_YELLOW = 12       # Warning temp indicator
LED_RED = 14          # Critical temp indicator

# Initialize hardware
temp_sensor = ADC(Pin(TEMP_SENSOR_PIN))
temp_sensor.atten(ADC.ATTN_11DB)

fan_led = Pin(FAN_LED_PIN, Pin.OUT)  # LED as fan indicator
buzzer = PWM(Pin(BUZZER_PIN), freq=1000, duty=0)
led_green = Pin(LED_GREEN, Pin.OUT)
led_yellow = Pin(LED_YELLOW, Pin.OUT)
led_red = Pin(LED_RED, Pin.OUT)

# Temperature thresholds
NORMAL_MAX = 25.0
CRITICAL = 30.0

def read_temperature():
    adc = temp_sensor.read()
    voltage = (adc / 4095) * 3.3
    temp = 15.0 + (voltage / 3.3) * 25.0
    return temp

while True:
    temp = read_temperature()
    
    # Update status LEDs
    if temp < NORMAL_MAX:
        led_green.value(1)
        led_yellow.value(0)
        led_red.value(0)
    elif temp < CRITICAL:
        led_green.value(0)
        led_yellow.value(1)
        led_red.value(0)
    else:
        led_green.value(0)
        led_yellow.value(0)
        led_red.value(1)
    
    # Control fan LED and buzzer
    if temp >= CRITICAL:
        fan_led.value(1)      # Fan LED ON
        buzzer.freq(2000)     # Buzzer ON
        buzzer.duty(512)
        print(f"CRITICAL: {temp:.1f}°C - Fan LED ON, Buzzer ON")
    elif temp >= NORMAL_MAX:
        fan_led.value(1)      # Fan LED ON
        buzzer.duty(0)        # Buzzer OFF
        print(f"WARNING: {temp:.1f}°C - Fan LED ON")
    else:
        fan_led.value(0)      # Fan LED OFF
        buzzer.duty(0)        # Buzzer OFF
        print(f"NORMAL: {temp:.1f}°C - All OFF")
    
    time.sleep(1)