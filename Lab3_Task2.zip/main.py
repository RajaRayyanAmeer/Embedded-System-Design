from machine import Pin, ADC, PWM
import time

# Pin Configuration
TEMP_PIN = 34
LED_PIN = 18
BUZZER_PIN = 19

# Hardware Setup
temp_sensor = ADC(Pin(TEMP_PIN))
temp_sensor.atten(ADC.ATTN_11DB)

warning_led = Pin(LED_PIN, Pin.OUT)

buzzer = PWM(Pin(BUZZER_PIN))
buzzer.freq(2000)
buzzer.duty(0)

# Temperature Limits
LOW_LIMIT = 18.0
HIGH_LIMIT = 25.0

# Buzzer Timing Setup
BUZZ_INTERVAL = 500  # milliseconds
last_toggle = 0
buzzer_state = False

# Temperature Conversion
def read_temperature():
    adc_val = temp_sensor.read()
    voltage = (adc_val / 4095) * 3.3
    temp = 15 + (voltage / 3.3) * 20
    return temp

# Main Loop
while True:
    temp = read_temperature()
    current_time = time.ticks_ms()
    
    if temp < LOW_LIMIT or temp > HIGH_LIMIT:
        # Unsafe condition
        warning_led.value(1)
        
        # Non-blocking buzzer toggle
        if time.ticks_diff(current_time, last_toggle) > BUZZ_INTERVAL:
            last_toggle = current_time
            buzzer_state = not buzzer_state
            
            if buzzer_state:
                buzzer.duty(512)
            else:
                buzzer.duty(0)
        
        print("ALERT! Temp:", round(temp, 1), "°C")
        
    else:
        # Safe condition
        warning_led.value(0)
        buzzer.duty(0)
        buzzer_state = False
        
        print("NORMAL Temp:", round(temp, 1), "°C")
    
    time.sleep(0.2)