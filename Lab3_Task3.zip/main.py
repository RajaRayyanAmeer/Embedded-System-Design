from machine import Pin
import time

# Pin Configuration
SENSOR_PIN = 15
LED_PIN = 18
BUZZER_PIN = 19

# Hardware Setup
sensor = Pin(SENSOR_PIN, Pin.IN, Pin.PULL_UP)
red_led = Pin(LED_PIN, Pin.OUT)
buzzer = Pin(BUZZER_PIN, Pin.OUT)

print("Security System Active - Monitoring...")

# Continuous Polling Loop
while True:
    intrusion = (sensor.value() == 0)  # Active LOW
    if intrusion:
        red_led.value(1)
        buzzer.value(1)
        print("INTRUSION DETECTED")
    else:
        red_led.value(0)
        buzzer.value(0)
        print("NO INTRUSION DETECTED")
    time.sleep(0.5)  