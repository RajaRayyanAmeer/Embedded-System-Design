from machine import Pin, ADC, PWM
import time

# Pin Configuration
TEMP_PIN = 34      # ADC
GREEN_LED = 25
YELLOW_LED = 26
RED_LED = 21
BUZZER_PIN = 21

# Hardware Initialization
temp_sensor = ADC(Pin(TEMP_PIN))
temp_sensor.atten(ADC.ATTN_11DB)

led_green = Pin(GREEN_LED, Pin.OUT)
led_yellow = Pin(YELLOW_LED, Pin.OUT)
led_red = Pin(RED_LED, Pin.OUT)

buzzer = PWM(Pin(BUZZER_PIN))
buzzer.freq(2000)
buzzer.duty(0)

# Temperature Thresholds
WARNING_LEVEL = 30.0
DANGER_LEVEL = 40.0

# Temperature Conversion
def read_temperature():
    adc_val = temp_sensor.read()
    voltage = (adc_val / 4095) * 3.3
    temp = 20 + (voltage / 3.3) * 30  # Simulated 20°C–50°C range
    return temp

# Main Loop
while True:
    temp = read_temperature()
    if temp < WARNING_LEVEL:
        led_green.value(1)
        led_yellow.value(0)
        led_red.value(0)
        buzzer.duty(0)
        state = "NORMAL"
    elif temp < DANGER_LEVEL:
        led_green.value(0)
        led_yellow.value(1)
        led_red.value(0)
        buzzer.duty(0)
        state = "WARNING"
    else:
        led_green.value(0)
        led_yellow.value(0)
        led_red.value(1)
        buzzer.duty(512)
        state = "DANGER"
    print("Temp:", round(temp, 1), "°C | State:", state)
    time.sleep(0.5)