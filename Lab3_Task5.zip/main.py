from machine import Pin, ADC
import time

# Pin Configuration
TEMP_PIN = 34
FAN_PIN = 19
LOW_LED_PIN = 21

# Hardware Setup
temp_sensor = ADC(Pin(TEMP_PIN))
temp_sensor.atten(ADC.ATTN_11DB)

fan = Pin(FAN_PIN, Pin.OUT)
low_led = Pin(LOW_LED_PIN, Pin.OUT)

# Temperature Thresholds
FAN_ON = 30.0
FAN_OFF = 18.0

HEAT_ON = 12.0
HEAT_OFF = 20.0

fan_state = False
low_state = False

# Temperature Conversion
def read_temperature():
    adc_val = temp_sensor.read()
    voltage = (adc_val / 4095) * 3.3
    temp = 10 + (voltage / 3.3) * 25  
    return temp

while True:
    temp = read_temperature()
    if temp >= FAN_ON:
        fan_state = True
    elif temp <= FAN_OFF:
        fan_state = False

    if temp <= HEAT_ON:
        low_state = True
    elif temp >= HEAT_OFF:
        low_state = False

    fan.value(fan_state)
    low_led.value(low_state)

    print("Temp:", round(temp,1), 
          "| Fan:", fan_state, 
          "| LowTempLED:", low_state)

    time.sleep(0.5)