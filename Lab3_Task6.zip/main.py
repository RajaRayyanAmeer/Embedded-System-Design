from machine import Pin, ADC
import time

# Pin Configuration
TEMP_PIN = 34
LED_PIN = 18
BUZZER_PIN = 19

# Hardware Setup
temp_sensor = ADC(Pin(TEMP_PIN))
temp_sensor.atten(ADC.ATTN_11DB)

warning_led = Pin(LED_PIN, Pin.OUT)
buzzer = Pin(BUZZER_PIN, Pin.OUT)

# Frost Threshold
FROST_THRESHOLD = 5.0

# Blinking control
BLINK_INTERVAL = 500  # ms
last_toggle = 0
led_state = False

# Temperature Conversion
def read_temperature():
    adc_val = temp_sensor.read()
    voltage = (adc_val / 4095) * 3.3
    temp = -5 + (voltage / 3.3) * 30   # Simulated -5°C to 25°C
    return temp

# Main Loop
while True:
    temp = read_temperature()
    current_time = time.ticks_ms()
    if temp < FROST_THRESHOLD:
        buzzer.value(1)
        if time.ticks_diff(current_time, last_toggle) > BLINK_INTERVAL:
            last_toggle = current_time
            led_state = not led_state
            warning_led.value(led_state)
        print("FROST ALERT! Temp:", round(temp, 1), "°C")
    else:
        buzzer.value(0)
        warning_led.value(0)
        led_state = False
        print("Normal Temp:", round(temp, 1), "°C")
    time.sleep(0.1)