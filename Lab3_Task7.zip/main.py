from machine import Pin, ADC
import time

# Pin Configuration
LIGHT_SENSOR_PIN = 34
LIGHT_OUTPUT_PIN = 18

# Hardware Setup
light_sensor = ADC(Pin(LIGHT_SENSOR_PIN))
light_sensor.atten(ADC.ATTN_11DB)

classroom_light = Pin(LIGHT_OUTPUT_PIN, Pin.OUT)

# Threshold
LIGHT_THRESHOLD = 2000

# Main Loop
while True:
    light_value = light_sensor.read()    
    if light_value > LIGHT_THRESHOLD:
        classroom_light.value(0)
        state = "Natural Light Sufficient - Lights OFF"
    else:
        classroom_light.value(1)
        state = "Low Light - Lights ON"    
    print("ADC:", light_value, "|", state)
    time.sleep(0.5)