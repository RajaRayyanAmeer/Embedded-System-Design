from machine import Pin, ADC
import time

# Sensor Abstraction Classes
class TemperatureSensor:
    def __init__(self, pin):
        self.adc = ADC(Pin(pin))
        self.adc.atten(ADC.ATTN_11DB)  # 0-3.6V range

    def read_raw(self):
        return self.adc.read()

    def read_temperature(self):
        # Potentiometer simulates temperature (0-4095 → 0-50°C for greenhouse)
        # Adjusted range for better simulation: 0-50°C
        return (self.read_raw() / 4095) * 50


class LightSensor:
    def __init__(self, pin):
        self.pin = Pin(pin, Pin.IN)
        # Optional: Add pull-up resistor for stable reading
        self.pin.init(Pin.IN, Pin.PULL_UP)

    def excessive_light(self):
        # LDR DO gives LOW when bright (Wokwi default behavior)
        # Returns True if light is excessive
        return self.pin.value() == 0
    
    def read_light_status(self):
        """Returns string description of light level"""
        return "EXCESSIVE" if self.excessive_light() else "NORMAL"


# Actuator Classes
class Fan:
    def __init__(self, pin):
        self.pin = Pin(pin, Pin.OUT)
        self.state = False

    def on(self):
        self.pin.value(1)
        self.state = True
        print("🌬️  Fan: ON")

    def off(self):
        self.pin.value(0)
        self.state = False
        print("🌬️  Fan: OFF")
    
    def is_on(self):
        return self.state


class Buzzer:
    def __init__(self, pin):
        self.pin = Pin(pin, Pin.OUT)
        self.state = False

    def on(self):
        self.pin.value(1)
        self.state = True
        print("🔊 BUZZER: ACTIVATED!")

    def off(self):
        self.pin.value(0)
        self.state = False
        print("🔇 Buzzer: OFF")
    
    def is_on(self):
        return self.state


# Greenhouse Controller
class GreenhouseController:
    def __init__(self, temp_sensor, light_sensor, fan, buzzer):
        self.temp_sensor = temp_sensor
        self.light_sensor = light_sensor
        self.fan = fan
        self.buzzer = buzzer

        # Threshold settings
        self.ventilation_threshold = 30      # °C - Fan turns on
        self.critical_temperature = 38       # °C - Buzzer activates
        
        # For tracking state changes
        self.last_temperature = 0
        self.last_light_state = False

    def update(self):
        # Read sensors
        temperature = self.temp_sensor.read_temperature()
        excessive_light = self.light_sensor.excessive_light()
        
        # Store for state change detection
        temp_changed = abs(temperature - self.last_temperature) > 0.5
        light_changed = excessive_light != self.last_light_state
        
        # Display current readings
        print("\n" + "="*50)
        print("🌡️  Temperature: {:.1f}°C".format(temperature))
        print("☀️  Light Level: {}".format(self.light_sensor.read_light_status()))
        print("-" * 50)
        
        # Decision Logic (priority-based)
        # Priority 1: Critical temperature - most dangerous
        if temperature >= self.critical_temperature:
            print("⚠️  CRITICAL: Temperature exceeds {}°C!".format(self.critical_temperature))
            self.fan.on()
            self.buzzer.on()
        
        # Priority 2: Excessive light (independent of temperature)
        elif excessive_light:
            print("⚠️  WARNING: Excessive sunlight detected!")
            self.fan.off()
            self.buzzer.on()
        
        # Priority 3: High temperature (ventilation needed)
        elif temperature > self.ventilation_threshold:
            print("🌡️  Temperature above {}°C - Ventilation required".format(self.ventilation_threshold))
            self.fan.on()
            self.buzzer.off()
        
        # Priority 4: Normal conditions
        else:
            if self.fan.is_on() or self.buzzer.is_on():
                print("✅ All conditions NORMAL - Resetting systems")
            self.fan.off()
            self.buzzer.off()
        
        # Show current actuator states
        print("📊 Status: Fan={}, Buzzer={}".format(
            "ON" if self.fan.is_on() else "OFF",
            "ON" if self.buzzer.is_on() else "OFF"
        ))
        
        # Update tracking variables
        self.last_temperature = temperature
        self.last_light_state = excessive_light

# Hardware Initialization (FIXED PINS)
temp_sensor = TemperatureSensor(35)  # Potentiometer on pin 35
light_sensor = LightSensor(34)        # LDR on pin 34
fan = Fan(33)                         # Blue LED on pin 33
buzzer = Buzzer(4)                    # Buzzer on pin 4

controller = GreenhouseController(
    temp_sensor, light_sensor, fan, buzzer
)

print("\n" + "="*50)
print("🌱 GREENHOUSE ENVIRONMENT CONTROLLER 🌱")
print("="*50)
print("System initialized successfully!")
print("Temperature sensor: Pin 35 (potentiometer)")
print("Light sensor: Pin 34 (LDR)")
print("Fan (LED): Pin 33")
print("Buzzer: Pin 4")
print("\nThresholds:")
print("- Ventilation fan: > {}°C".format(controller.ventilation_threshold))
print("- Critical alert: > {}°C or excessive light".format(controller.critical_temperature))
print("\n💡 TIP: Adjust the potentiometer to change temperature")
print("💡 TIP: Cover/uncover the LDR to simulate light changes")
print("="*50 + "\n")

# Main Loop
while True:
    try:
        controller.update()
        time.sleep(1)  # Update every second
    except KeyboardInterrupt:
        print("\n\n🛑 System shutdown")
        fan.off()
        buzzer.off()
        break
    except Exception as e:
        print("Error: {}".format(e))
        time.sleep(1)