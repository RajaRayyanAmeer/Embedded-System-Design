from machine import Pin, ADC
import time

# Temperature Sensor Class
class TemperatureSensor:
    def __init__(self, pin):
        self.adc = ADC(Pin(pin))
        self.adc.atten(ADC.ATTN_11DB)
    
    def read_temp(self):
        # Convert ADC (0-4095) to temperature (0-50°C)
        return (self.adc.read() / 4095) * 50

# System States
class SystemState:
    NORMAL = 0
    WARNING = 1
    CRITICAL = 2

# Main Controller
class MedicalMonitor:
    def __init__(self, temp_sensor, led, buzzer):
        self.temp_sensor = temp_sensor
        self.led = led
        self.buzzer = buzzer
        self.state = SystemState.NORMAL
        self.warning_threshold = 35
        self.critical_threshold = 42
    
    def check_state(self, temp):
        if temp >= self.critical_threshold:
            return SystemState.CRITICAL
        elif temp >= self.warning_threshold:
            return SystemState.WARNING
        else:
            return SystemState.NORMAL
    
    def update(self):
        temp = self.temp_sensor.read_temp()
        new_state = self.check_state(temp)
        
        # State transition
        if new_state != self.state:
            self.state = new_state
            print(f"\nState: {self.get_state_name()} | Temp: {temp:.1f}°C")
        
        # State actions
        if self.state == SystemState.NORMAL:
            self.led.off()
            self.buzzer.off()
            
        elif self.state == SystemState.WARNING:
            self.led.on()
            self.buzzer.off()
            print(f"⚠️  Warning! Temp: {temp:.1f}°C")
            
        elif self.state == SystemState.CRITICAL:
            self.led.on()
            self.buzzer.on()
            print(f"🔴 CRITICAL! Temp: {temp:.1f}°C")
    
    def get_state_name(self):
        return ["NORMAL", "WARNING", "CRITICAL"][self.state]

# Hardware Setup
temp_sensor = TemperatureSensor(35)
led = Pin(33, Pin.OUT)
buzzer = Pin(4, Pin.OUT)

monitor = MedicalMonitor(temp_sensor, led, buzzer)

print("Medical Equipment Temperature Monitor")
print("Thresholds: Normal <35°C | Warning 35-42°C | Critical >42°C")
print("Adjust potentiometer to simulate temperature\n")

# Main Loop
while True:
    monitor.update()
    time.sleep(1)