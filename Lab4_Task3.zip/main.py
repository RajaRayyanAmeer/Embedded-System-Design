from machine import Pin, ADC
import time

# Sensor Class
class TemperatureSensor:
    def __init__(self, pin):
        self.adc = ADC(Pin(pin))
        self.adc.atten(ADC.ATTN_11DB)
    
    def read(self):
        # Convert ADC (0-4095) to temperature (0-100°C)
        return (self.adc.read() / 4095) * 100

# Actuator Classes
class Motor:
    def __init__(self, pin):
        self.pin = Pin(pin, Pin.OUT)
        self.running = False
    
    def start(self):
        self.pin.value(1)
        self.running = True
        print("Motor: STARTED")
    
    def stop(self):
        self.pin.value(0)
        self.running = False
        print("Motor: STOPPED")
    
    def is_running(self):
        return self.running

class Buzzer:
    def __init__(self, pin):
        self.pin = Pin(pin, Pin.OUT)
    
    def on(self):
        self.pin.value(1)
        print("Buzzer: ON")
    
    def off(self):
        self.pin.value(0)
        print("Buzzer: OFF")

class StatusLED:
    def __init__(self, pin):
        self.pin = Pin(pin, Pin.OUT)
    
    def running(self):
        self.pin.value(1)
    
    def shutdown(self):
        self.pin.value(0)

# Protection System
class MotorProtectionSystem:
    def __init__(self, sensor, motor, buzzer, led):
        self.sensor = sensor
        self.motor = motor
        self.buzzer = buzzer
        self.led = led
        self.safe_threshold = 75  # °C
        self.protection_active = False
    
    def check_condition(self):
        temp = self.sensor.read()
        print(f"Temperature: {temp:.1f}°C")
        
        if temp > self.safe_threshold and not self.protection_active:
            # Unsafe condition detected
            self.protection_active = True
            self.motor.stop()
            self.buzzer.on()
            self.led.shutdown()
            print("⚠️ PROTECTION ACTIVE: Motor shutdown!")
            
        elif temp <= self.safe_threshold and self.protection_active:
            # Safe condition restored
            self.protection_active = False
            self.buzzer.off()
            print("✅ Safe conditions restored")
    
    def update(self):
        if not self.protection_active:
            # Motor runs normally when safe
            if not self.motor.is_running():
                self.motor.start()
                self.led.running()
        
        self.check_condition()

# Hardware Setup
sensor = TemperatureSensor(35)
motor = Motor(32)      # Red LED represents motor
buzzer = Buzzer(4)
status_led = StatusLED(33)  # Green LED

protector = MotorProtectionSystem(sensor, motor, buzzer, status_led)

print("Industrial Motor Protection System")
print(f"Safe threshold: {protector.safe_threshold}°C")
print("Adjust potentiometer to simulate temperature\n")

# Main Loop
while True:
    protector.update()
    time.sleep(1)