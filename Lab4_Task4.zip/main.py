from machine import Pin, ADC
import time

# Sensor Abstraction
class TemperatureSensor:
    def __init__(self, pin, min_temp=-10, max_temp=30):
        self.adc = ADC(Pin(pin))
        self.adc.atten(ADC.ATTN_11DB)
        self.min_temp = min_temp
        self.max_temp = max_temp
    
    def read(self):
        # Convert ADC (0-4095) to temperature range
        raw = self.adc.read()
        return self.min_temp + (raw / 4095) * (self.max_temp - self.min_temp)

# Actuator Abstraction
class CoolingSystem:
    def __init__(self, pin):
        self.pin = Pin(pin, Pin.OUT)
    
    def on(self):
        self.pin.value(1)
        print("Cooling: ON")
    
    def off(self):
        self.pin.value(0)
        print("Cooling: OFF")

class Alarm:
    def __init__(self, pin):
        self.pin = Pin(pin, Pin.OUT)
    
    def on(self):
        self.pin.value(1)
        print("ALARM: ACTIVATED")
    
    def off(self):
        self.pin.value(0)
        print("Alarm: OFF")

class StatusIndicator:
    def __init__(self, pin):
        self.pin = Pin(pin, Pin.OUT)
    
    def safe(self):
        self.pin.value(1)
    
    def unsafe(self):  # Fixed: added 'def' keyword
        self.pin.value(0)

# Storage Controller
class ColdStorageController:
    def __init__(self, sensor, cooling, alarm, indicator):
        self.sensor = sensor
        self.cooling = cooling
        self.alarm = alarm
        self.indicator = indicator
        
        # Configurable thresholds
        self.safe_limit = 5.0      # °C - Cooling turns on above this
        self.critical_limit = 10.0  # °C - Alarm activates above this
    
    def update(self):
        temp = self.sensor.read()
        print(f"Temperature: {temp:.1f}°C")
        
        # Layered decision logic
        if temp >= self.critical_limit:
            self.cooling.on()
            self.alarm.on()
            self.indicator.unsafe()
            print("🔴 CRITICAL: Alarm activated!")
            
        elif temp >= self.safe_limit:
            self.cooling.on()
            self.alarm.off()
            self.indicator.unsafe()
            print("⚠️ Cooling: Temperature above safe limit")
            
        else:
            self.cooling.off()
            self.alarm.off()
            self.indicator.safe()
            print("✅ Temperature within safe range")

# Hardware Setup
sensor = TemperatureSensor(35, min_temp=-10, max_temp=30)
cooling = CoolingSystem(33)      # Blue LED
alarm = Alarm(4)                 # Buzzer
indicator = StatusIndicator(32)  # Green LED

# Create controller with custom thresholds
storage = ColdStorageController(sensor, cooling, alarm, indicator)

print("Cold-Storage Monitoring System")
print(f"Safe limit: {storage.safe_limit}°C")
print(f"Critical limit: {storage.critical_limit}°C")
print("Adjust potentiometer to simulate temperature\n")

# Main Loop
while True:
    storage.update()
    time.sleep(1)