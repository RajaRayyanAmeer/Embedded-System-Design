from machine import Pin, ADC
import time

# Sensor Classes
class TemperatureSensor:
    def __init__(self, pin):
        self.adc = ADC(Pin(pin))
        self.adc.atten(ADC.ATTN_11DB)
    
    def read(self):
        # Convert ADC (0-4095) to temperature (0-50°C)
        return (self.adc.read() / 4095) * 50

class MoistureSensor:
    def __init__(self, pin):
        self.adc = ADC(Pin(pin))
        self.adc.atten(ADC.ATTN_11DB)
    
    def read(self):
        # Convert ADC (0-4095) to moisture (0-100%)
        # Higher ADC = wetter soil
        return (self.adc.read() / 4095) * 100

# Actuator Classes
class IrrigationMotor:
    def __init__(self, pin):
        self.pin = Pin(pin, Pin.OUT)
    
    def on(self):
        self.pin.value(1)
        print("💧 Irrigation Motor: ON")
    
    def off(self):
        self.pin.value(0)
        print("💧 Irrigation Motor: OFF")

class WarningIndicator:
    def __init__(self, pin):
        self.pin = Pin(pin, Pin.OUT)
    
    def on(self):
        self.pin.value(1)
        print("⚠️ Warning Indicator: ON")
    
    def off(self):
        self.pin.value(0)
        print("⚠️ Warning Indicator: OFF")

# Safety Controller
class IrrigationSafetyController:
    def __init__(self, temp_sensor, moisture_sensor, motor, warning):
        self.temp_sensor = temp_sensor
        self.moisture_sensor = moisture_sensor
        self.motor = motor
        self.warning = warning
        
        # Thresholds
        self.max_temp = 35.0        # °C - Unsafe above this
        self.dry_threshold = 30.0   # % - Irrigate below this
    
    def check_safety(self):
        temp = self.temp_sensor.read()
        moisture = self.moisture_sensor.read()
        
        print(f"Temperature: {temp:.1f}°C | Moisture: {moisture:.1f}%")
        
        # Safety first: Check temperature
        if temp > self.max_temp:
            self.motor.off()
            self.warning.on()
            print("🔥 UNSAFE: High temperature detected - Motor locked out")
            return False
        
        # Safe temperature - check moisture
        if moisture < self.dry_threshold:
            self.motor.on()
            self.warning.off()
            print("✅ SAFE: Temperature OK, Soil dry - Irrigation running")
            return True
        else:
            self.motor.off()
            self.warning.off()
            print("🌧️ Soil moisture adequate - No irrigation needed")
            return False
    
    def update(self):
        return self.check_safety()

# Hardware Setup
temp_sensor = TemperatureSensor(35)
moisture_sensor = MoistureSensor(34)
motor = IrrigationMotor(33)      # Red LED
warning = WarningIndicator(32)   # Yellow LED

controller = IrrigationSafetyController(temp_sensor, moisture_sensor, motor, warning)

print("Smart Irrigation Safety Controller")
print(f"Max safe temperature: {controller.max_temp}°C")
print(f"Dry soil threshold: {controller.dry_threshold}%")
print("\nControls:")
print("- Potentiometer 1: Temperature (0-50°C)")
print("- Potentiometer 2: Soil moisture (0-100%)")
print("- Motor runs only when: Temp OK + Soil Dry")
print("- Warning activates when: Temp UNSAFE\n")

# Main Loop
while True:
    controller.update()
    time.sleep(1)