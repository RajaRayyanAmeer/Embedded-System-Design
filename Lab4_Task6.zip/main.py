from machine import Pin, ADC
import time

# Temperature Sensor
class TemperatureSensor:
    def __init__(self, pin):
        self.adc = ADC(Pin(pin))
        self.adc.atten(ADC.ATTN_11DB)
    
    def read(self):
        # Convert ADC (0-4095) to temperature (0-120°C)
        return (self.adc.read() / 4095) * 120

# Alert System
class VehicleOverheatAlert:
    def __init__(self, temp_sensor, led, buzzer):
        self.temp_sensor = temp_sensor
        self.led = led
        self.buzzer = buzzer
        self.state = "NORMAL"
        
        # Temperature thresholds
        self.warning_temp = 85.0    # °C - LED turns on
        self.critical_temp = 100.0  # °C - Buzzer activates
    
    def get_state(self, temp):
        if temp >= self.critical_temp:
            return "CRITICAL"
        elif temp >= self.warning_temp:
            return "WARNING"
        else:
            return "NORMAL"
    
    def update(self):
        temp = self.temp_sensor.read()
        new_state = self.get_state(temp)
        
        # Handle state transition
        if new_state != self.state:
            self.state = new_state
            print(f"\n{'='*40}")
            print(f"STATE: {self.state}")
            print(f"Temperature: {temp:.1f}°C")
            print(f"{'='*40}")
        
        # Alert actions based on state
        if self.state == "NORMAL":
            self.led.off()
            self.buzzer.off()
            print(f"✅ Engine: NORMAL | Temp: {temp:.1f}°C")
            
        elif self.state == "WARNING":
            self.led.on()
            self.buzzer.off()
            print(f"⚠️ WARNING: Engine overheating! Temp: {temp:.1f}°C")
            
        elif self.state == "CRITICAL":
            self.led.on()
            self.buzzer.on()
            print(f"🔴 CRITICAL: Engine failure risk! Temp: {temp:.1f}°C")
            print(f"🚨 IMMEDIATE SHUTDOWN REQUIRED!")

# Hardware Setup
temp_sensor = TemperatureSensor(35)
warning_led = Pin(33, Pin.OUT)
buzzer = Pin(4, Pin.OUT)

alert_system = VehicleOverheatAlert(temp_sensor, warning_led, buzzer)

print("Vehicle Overheat Alert System")
print(f"Warning threshold: {alert_system.warning_temp}°C (LED ON)")
print(f"Critical threshold: {alert_system.critical_temp}°C (BUZZER ON)")
print("Adjust potentiometer to simulate engine temperature\n")

# Main Loop
while True:
    alert_system.update()
    time.sleep(1)