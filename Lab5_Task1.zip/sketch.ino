#define EMERGENCY_BTN 33
#define RESET_BTN 32
#define MOTOR_LED 25
#define ALARM_LED 26
#define BUZZER 27

volatile bool emergency_flag = false;

void IRAM_ATTR emergency_isr() {
  emergency_flag = true;  
}

void setup() {
  Serial.begin(115200);
  
  pinMode(EMERGENCY_BTN, INPUT_PULLUP);
  pinMode(RESET_BTN, INPUT_PULLUP);
  pinMode(MOTOR_LED, OUTPUT);
  pinMode(ALARM_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  
  attachInterrupt(digitalPinToInterrupt(EMERGENCY_BTN), emergency_isr, FALLING);
  
  digitalWrite(MOTOR_LED, HIGH);
  digitalWrite(ALARM_LED, LOW);
  digitalWrite(BUZZER, LOW);
  
  Serial.println("System Started - Normal Operation");
}

void loop() {
  if (emergency_flag) {            
    digitalWrite(MOTOR_LED, LOW);  
    digitalWrite(ALARM_LED, HIGH); 
    digitalWrite(BUZZER, HIGH);    
    Serial.println("EMERGENCY STOP ACTIVATED, System Locked");
    
    while (digitalRead(RESET_BTN) == HIGH) { 
      delay(50);
    }
    
    emergency_flag = false;
    digitalWrite(ALARM_LED, LOW);
    digitalWrite(BUZZER, LOW);
    digitalWrite(MOTOR_LED, HIGH);
    Serial.println("System Reset, Resuming Normal Operation");
  }
  
  delay(20);  
}