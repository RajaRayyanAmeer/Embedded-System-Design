#define SENSOR_BTN 33
#define WARN_LED 25
#define EMERG_LED 26
#define BUZZER 27

const unsigned long WINDOW_MS = 5000;        
const int ESCALATE_COUNT = 3;                
const unsigned long DEBOUNCE_MS = 200;       

volatile int trigger_count = 0;
volatile unsigned long window_start = 0;
volatile unsigned long last_trigger_time = 0;
volatile bool emergency_mode = false;

int trigger_count_copy = 0;
unsigned long window_start_copy = 0;

void IRAM_ATTR sensor_isr() {
  unsigned long now = millis();
  
  if ((now - last_trigger_time) < DEBOUNCE_MS) {
    return;
  }
  
  last_trigger_time = now;
  trigger_count++;
  
  if (trigger_count == 1) {
    window_start = now;
  }
}

void setup() {
  Serial.begin(115200);
  
  pinMode(SENSOR_BTN, INPUT_PULLUP);
  pinMode(WARN_LED, OUTPUT);
  pinMode(EMERG_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  
  attachInterrupt(digitalPinToInterrupt(SENSOR_BTN), sensor_isr, FALLING);
  
  digitalWrite(WARN_LED, LOW);
  digitalWrite(EMERG_LED, LOW);
  digitalWrite(BUZZER, LOW);
  
  Serial.println("System Started - Monitoring Machine Warnings");
  Serial.printf("Escalation threshold: %d triggers within %lu ms\n", ESCALATE_COUNT, WINDOW_MS);
}

void loop() {
  if (emergency_mode) {
    digitalWrite(EMERG_LED, HIGH);
    digitalWrite(BUZZER, HIGH);
    digitalWrite(WARN_LED, LOW);
    
    delay(100);  
    return;      
  }

  unsigned long now = millis();
  
  if (trigger_count > 0 && ((now - window_start) > WINDOW_MS)) {
    noInterrupts();
    int count = trigger_count;
    trigger_count = 0;  
    window_start = 0;
    interrupts();
    
    if (count >= ESCALATE_COUNT) {
      emergency_mode = true;
      Serial.print("ESCALATED TO EMERGENCY MODE - ");
      Serial.print(count);
      Serial.println(" triggers detected within window!");
    } else {
      Serial.print("Warning - ");
      Serial.print(count);
      Serial.println(" trigger(s), no escalation");
      
      digitalWrite(WARN_LED, HIGH);
      delay(100);  
      digitalWrite(WARN_LED, LOW);
    }
  }

  noInterrupts();
  int current_triggers = trigger_count;
  interrupts();
  
  if (current_triggers > 0 && !emergency_mode) {
    digitalWrite(WARN_LED, HIGH);
  } else {
    digitalWrite(WARN_LED, LOW);
  }
  delay(20);  
}