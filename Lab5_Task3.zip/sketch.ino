#define BTN_TEMP 33    
#define BTN_POWER 32   
#define BTN_FAULT 34   
#define LED_TEMP 25    
#define LED_POWER 26   
#define LED_FAULT 27   
#define BUZZER 14      

volatile bool flag_temp = false;   
volatile bool flag_power = false;  
volatile bool flag_fault = false;  

void IRAM_ATTR isr_temp() {
  flag_temp = true;   
}

void IRAM_ATTR isr_power() {
  flag_power = true;  
}

void IRAM_ATTR isr_fault() {
  flag_fault = true;  
}

void setup() {
  Serial.begin(115200);
  
  pinMode(BTN_TEMP, INPUT_PULLUP);
  pinMode(BTN_POWER, INPUT_PULLUP);
  pinMode(BTN_FAULT, INPUT_PULLUP);
  pinMode(LED_TEMP, OUTPUT);
  pinMode(LED_POWER, OUTPUT);
  pinMode(LED_FAULT, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  
  attachInterrupt(digitalPinToInterrupt(BTN_TEMP), isr_temp, FALLING);
  attachInterrupt(digitalPinToInterrupt(BTN_POWER), isr_power, FALLING);
  attachInterrupt(digitalPinToInterrupt(BTN_FAULT), isr_fault, FALLING);
  
  clear_all_outputs();
  
  Serial.println(" Hospital Equipment Alert Controller ");
  Serial.println("Priority Levels:");
  Serial.println("  1. TEMPERATURE Alert (Lowest)");
  Serial.println("  2. POWER FAILURE Alert");
  Serial.println("  3. EQUIPMENT FAULT Alert (Highest)");
  Serial.println("System Ready - Monitoring...\n");
}

void clear_all_outputs() {
  digitalWrite(LED_TEMP, LOW);
  digitalWrite(LED_POWER, LOW);
  digitalWrite(LED_FAULT, LOW);
  digitalWrite(BUZZER, LOW);
}

void loop() {
  if (flag_fault) {
    clear_all_outputs();
    Serial.println("[CRITICAL] Equipment Fault Alert Activated!");
    digitalWrite(LED_FAULT, HIGH);  
    for (int i = 0; i < 5; i++) {
      digitalWrite(BUZZER, HIGH);
      delay(100);
      digitalWrite(BUZZER, LOW);
      delay(100);
    }
    flag_fault = false;  
    clear_all_outputs();
    Serial.println("Equipment Fault Alert Serviced\n");
  }
  
  else if (flag_power) {
    clear_all_outputs();
    Serial.println("[WARNING] Power Failure Alert Activated!");
    digitalWrite(LED_POWER, HIGH);  
    digitalWrite(BUZZER, HIGH);     
    delay(2000);      
    digitalWrite(BUZZER, LOW);
    flag_power = false;  
    clear_all_outputs();
    Serial.println("Power Failure Alert Serviced\n");
  }
  
  else if (flag_temp) {
    clear_all_outputs();
    Serial.println("[INFO] Temperature Alert Activated!");
    digitalWrite(LED_TEMP, HIGH);
    digitalWrite(BUZZER, HIGH);
    delay(500);  
    digitalWrite(BUZZER, LOW);
    flag_temp = false;  
    clear_all_outputs();
    Serial.println("Temperature Alert Serviced\n");
  }
  
  delay(20);  
}