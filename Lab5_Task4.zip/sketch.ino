#define SAFETY_BTN 33    
#define MAINT_BTN 32     
#define MAINT_LED 25     
#define SAFETY_LED 26    
#define BUZZER 27        

volatile bool safety_flag = false;   
volatile bool maint_flag = false;    

void IRAM_ATTR isr_safety() {
  safety_flag = true;
  maint_flag = false;
}

void IRAM_ATTR isr_maint() {
  if (!safety_flag) {
    maint_flag = true;
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(SAFETY_BTN, INPUT_PULLUP);
  pinMode(MAINT_BTN, INPUT_PULLUP);
  pinMode(MAINT_LED, OUTPUT);
  pinMode(SAFETY_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  
  attachInterrupt(digitalPinToInterrupt(SAFETY_BTN), isr_safety, FALLING);
  attachInterrupt(digitalPinToInterrupt(MAINT_BTN), isr_maint, FALLING);
  
  digitalWrite(MAINT_LED, LOW);
  digitalWrite(SAFETY_LED, LOW);
  digitalWrite(BUZZER, LOW);
  
  Serial.println(" Factory Maintenance Request System ");
  Serial.println("Priority: SAFETY ALERT > Maintenance Request");
  Serial.println("System Ready, Normal Operation\n");
}

void loop() {
  if (safety_flag) {
    digitalWrite(MAINT_LED, LOW);
    digitalWrite(SAFETY_LED, HIGH);   
    digitalWrite(BUZZER, HIGH);       
    Serial.println(" SAFETY ALERT ACTIVE, Maintenance Requests Suppressed ");
    delay(1000);
    safety_flag = false;
    digitalWrite(SAFETY_LED, LOW);
    digitalWrite(BUZZER, LOW);
    Serial.println("Safety Condition Cleared, Resuming Normal Operation\n");
  }
  
  else if (maint_flag) {
    Serial.println("Maintenance Request Received, Activating Visual Indicator");
    for (int i = 0; i < 6; i++) {
      digitalWrite(MAINT_LED, HIGH);
      delay(250);
      digitalWrite(MAINT_LED, LOW);
      delay(250);
    }
    maint_flag = false;
    digitalWrite(MAINT_LED, LOW);
    Serial.println("Maintenance Indication Complete, Ready for Next Request\n");
  }
  delay(20);
}