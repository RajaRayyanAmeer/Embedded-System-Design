#define BTN_NORMAL 33    
#define BTN_WARNING 32    
#define BTN_CRITICAL 4    
#define LED_GREEN 25      
#define LED_YELLOW 26     
#define LED_RED 27        

enum SystemState {
  NORMAL = 0,
  WARNING = 1,
  CRITICAL = 2
};

volatile SystemState current_state = NORMAL;
SystemState last_displayed_state = (SystemState)(-1);

const unsigned long DEBOUNCE_MS = 150;
volatile unsigned long last_normal_ts = 0;
volatile unsigned long last_warning_ts = 0;
volatile unsigned long last_critical_ts = 0;

void IRAM_ATTR isr_normal() {
  unsigned long now = millis();
  
  if ((now - last_normal_ts) < DEBOUNCE_MS) {
    return;
  }
  last_normal_ts = now;
  
  if (current_state != CRITICAL) {
    current_state = NORMAL;
  }
}

void IRAM_ATTR isr_warning() {
  unsigned long now = millis();
  
  if ((now - last_warning_ts) < DEBOUNCE_MS) {
    return;
  }
  last_warning_ts = now;
  
  if (current_state != CRITICAL) {
    current_state = WARNING;
  }
}

void IRAM_ATTR isr_critical() {
  unsigned long now = millis();
  
  if ((now - last_critical_ts) < DEBOUNCE_MS) {
    return;
  }
  last_critical_ts = now;
  
  current_state = CRITICAL;
}

void update_leds(SystemState state) {
  digitalWrite(LED_GREEN, LOW);
  digitalWrite(LED_YELLOW, LOW);
  digitalWrite(LED_RED, LOW);
  
  switch (state) {
    case NORMAL:
      digitalWrite(LED_GREEN, HIGH);
      break;
    case WARNING:
      digitalWrite(LED_YELLOW, HIGH);
      break;
    case CRITICAL:
      digitalWrite(LED_RED, HIGH);
      break;
  }
}

const char* state_to_string(SystemState state) {
  switch (state) {
    case NORMAL:   return "NORMAL";
    case WARNING:  return "WARNING";
    case CRITICAL: return "CRITICAL";
    default:       return "UNKNOWN";
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(BTN_NORMAL, INPUT_PULLUP);
  pinMode(BTN_WARNING, INPUT_PULLUP);
  pinMode(BTN_CRITICAL, INPUT_PULLUP);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_YELLOW, OUTPUT);
  pinMode(LED_RED, OUTPUT);
  
  attachInterrupt(digitalPinToInterrupt(BTN_NORMAL), isr_normal, FALLING);
  attachInterrupt(digitalPinToInterrupt(BTN_WARNING), isr_warning, FALLING);
  attachInterrupt(digitalPinToInterrupt(BTN_CRITICAL), isr_critical, FALLING);
  
  update_leds(NORMAL);
  
  Serial.println(" Smart Control Room Indicator Panel ");
  Serial.println("Priority: CRITICAL > WARNING > NORMAL");
  Serial.println("Panel Initialized, Displaying NORMAL Status\n");
}

void loop() {
  noInterrupts();
  SystemState state = current_state;
  interrupts();
  
  if (state != last_displayed_state) {
    update_leds(state);
    last_displayed_state = state;
    Serial.print("[");
    Serial.print(millis());
    Serial.print("] Panel State: ");
    Serial.println(state_to_string(state));
  }
  
  delay(20);  
}