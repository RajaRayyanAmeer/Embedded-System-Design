#include <Wire.h>
#define POT_PIN 34        
#define SIGNAL_PIN 26     
#define I2C_SDA 21        
#define I2C_SCL 22        
#define HR_CRITICAL_HIGH 120    
#define SPO2_CRITICAL_LOW 90    

struct VitalSigns {
  int heart_rate;
  int spo2;
  bool critical;
};

void setup() {
  Serial.begin(9600);
  Wire.begin(I2C_SDA, I2C_SCL);
  pinMode(SIGNAL_PIN, OUTPUT);
  digitalWrite(SIGNAL_PIN, LOW); 
  Serial.println("ESP-A Sensor Node Initialized");
  Serial.println("Reading vital signs...");
  Serial.println("Format: HR,SpO2,Critical");
}

void loop() {
  VitalSigns vitals = read_vital_signs();
  transmit_vital_data(vitals);
  digitalWrite(SIGNAL_PIN, vitals.critical ? HIGH : LOW);
  Serial.print("HR: ");
  Serial.print(vitals.heart_rate);
  Serial.print(" BPM | SpO2: ");
  Serial.print(vitals.spo2);
  Serial.print("% | Status: ");
  Serial.println(vitals.critical ? "CRITICAL" : "NORMAL");  
  delay(1000);  
}

VitalSigns read_vital_signs() {
  VitalSigns vitals;
  int pot_value = analogRead(POT_PIN);
  
  vitals.heart_rate = map(pot_value, 0, 4095, 50, 150);
  vitals.spo2 = map(pot_value, 0, 4095, 100, 85);
  vitals.critical = (vitals.heart_rate > HR_CRITICAL_HIGH || 
                     vitals.spo2 < SPO2_CRITICAL_LOW);  
  return vitals;
}

void transmit_vital_data(VitalSigns vitals) {
  Serial.print(vitals.heart_rate);
  Serial.print(",");
  Serial.print(vitals.spo2);
  Serial.print(",");
  Serial.println(vitals.critical ? "1" : "0");
}