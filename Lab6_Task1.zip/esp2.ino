#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_GFX.h>
#define BUZZER_PIN 5      
#define SIGNAL_PIN 33     
#define LED_PIN 15        
#define OLED_ADDRESS 0x3C   

LiquidCrystal_I2C lcd(0x27, 16, 2);
Adafruit_SSD1306 display(128, 64, &Wire, -1);

bool alarm_enabled = true;
int heart_rate = 0, spo2_level = 0;
bool critical_state = false;
String serial_buffer = "";
unsigned long last_data_received = 0, last_alarm_toggle = 0;
bool buzzer_state = false;

void setup() {
  Serial.begin(9600);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(SIGNAL_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(LED_PIN, LOW);
  
  Wire.begin(21, 22);
  
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Medical Ward");
  lcd.setCursor(0, 1);
  lcd.print("Monitor v1.0");
  delay(2000);
  lcd.clear();
  
  if (display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDRESS)) {
    display.clearDisplay();
    display.setTextSize(2);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(10, 20);
    display.println("Medical");
    display.setCursor(20, 40);
    display.println("Monitor");
    display.display();
    delay(2000);
    display.clearDisplay();
  }
  
  Serial.println("ESP-B Display Node Ready");
  Serial.println("Commands: ALARM OFF | ALARM ON");
}

void loop() {
  process_serial_data();
  critical_state = digitalRead(SIGNAL_PIN);
  update_displays();
  handle_alarms();
  delay(100);
}

void process_serial_data() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      serial_buffer.trim();
      
      if (serial_buffer == "ALARM OFF") {
        alarm_enabled = false;
        digitalWrite(BUZZER_PIN, LOW);
        digitalWrite(LED_PIN, LOW);
        Serial.println("ACK: Alarm silenced");
      }
      else if (serial_buffer == "ALARM ON") {
        alarm_enabled = true;
        Serial.println("ACK: Alarm re-enabled");
      }
      else {
        int c1 = serial_buffer.indexOf(',');
        int c2 = serial_buffer.indexOf(',', c1 + 1);
        if (c1 > 0 && c2 > c1) {
          heart_rate = serial_buffer.substring(0, c1).toInt();
          spo2_level = serial_buffer.substring(c1 + 1, c2).toInt();
          last_data_received = millis();
          Serial.print("Vitals - HR: ");
          Serial.print(heart_rate);
          Serial.print(" BPM, SpO2: ");
          Serial.print(spo2_level);
          Serial.print("%, Status: ");
          Serial.println(critical_state ? "CRITICAL" : "NORMAL");
        }
      }
      serial_buffer = "";
    } else if (c != '\r') {
      serial_buffer += c;
    }
  }
}

void update_displays() {
  lcd.setCursor(0, 0);
  lcd.print("HR: ");
  lcd.print(heart_rate);
  lcd.print(" BPM   ");
  lcd.setCursor(0, 1);
  lcd.print("SpO2: ");
  lcd.print(spo2_level);
  lcd.print("% ");
  lcd.print(critical_state ? "CRIT!" : "OK   ");
  
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("VITAL SIGNS MONITOR");
  display.setTextSize(2);
  display.setCursor(0, 15);
  display.print("HR:");
  display.print(heart_rate);
  display.print("BPM");
  display.setCursor(0, 38);
  display.print("SpO2:");
  display.print(spo2_level);
  display.print("%");
  
  if (critical_state) {
    display.fillRect(0, 56, 128, 8, SSD1306_WHITE);
    display.setTextColor(SSD1306_BLACK);
    display.setCursor(25, 56);
    display.println("CRITICAL!");
  } else {
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(35, 56);
    display.println("OK");
  }
  display.display();
  
  if (millis() - last_data_received > 3000 && heart_rate > 0) {
    heart_rate = 0;
    spo2_level = 0;
    Serial.println("WARNING: Data timeout!");
  }
}

void handle_alarms() {
  if (critical_state && alarm_enabled) {
    if (millis() - last_alarm_toggle > 500) {
      buzzer_state = !buzzer_state;
      digitalWrite(BUZZER_PIN, buzzer_state);
      digitalWrite(LED_PIN, buzzer_state);
      last_alarm_toggle = millis();
    }
  } else {
    digitalWrite(BUZZER_PIN, LOW);
    digitalWrite(LED_PIN, LOW);
    buzzer_state = false;
  }
}