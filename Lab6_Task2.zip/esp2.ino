#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_GFX.h>

#define BUZZER_PIN 5
#define SIGNAL_PIN 33
#define LED_PIN 15
#define OLED_ADDR 0x3C

LiquidCrystal_I2C lcd(0x27, 16, 2);
Adafruit_SSD1306 oled(128, 64, &Wire, -1);

float accel_x = 0, accel_y = 0, accel_z = 0, temperature = 0;
bool disturbance = false;
String serial_buf = "";
bool auto_mode = true;
unsigned long last_beep = 0;
int beep_count = 0;

void setup() {
  Serial.begin(9600);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(SIGNAL_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(LED_PIN, LOW);
  
  Wire.begin(21, 22);
  
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Greenhouse");
  lcd.setCursor(0, 1);
  lcd.print("Monitor v1.0");
  delay(1500);
  lcd.clear();
  
  if (oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    oled.clearDisplay();
    oled.setTextSize(2);
    oled.setTextColor(SSD1306_WHITE);
    oled.setCursor(15, 20);
    oled.println("Greenhouse");
    oled.setCursor(30, 40);
    oled.println("Monitor");
    oled.display();
    delay(1500);
    oled.clearDisplay();
  }
  
  Serial.println("ESP-B Ready");
  Serial.println("Commands: MODE AUTO | MODE MANUAL");
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      serial_buf.trim();
      
      if (serial_buf == "MODE AUTO") {
        auto_mode = true;
        Serial.println("ACK: AUTO mode");
      }
      else if (serial_buf == "MODE MANUAL") {
        auto_mode = false;
        Serial.println("ACK: MANUAL mode");
      }
      else {
        int c1 = serial_buf.indexOf(',');
        int c2 = serial_buf.indexOf(',', c1 + 1);
        int c3 = serial_buf.indexOf(',', c2 + 1);
        int c4 = serial_buf.indexOf(',', c3 + 1);
        
        if (c1 > 0 && c4 > c3) {
          accel_x = serial_buf.substring(0, c1).toFloat();
          accel_y = serial_buf.substring(c1 + 1, c2).toFloat();
          accel_z = serial_buf.substring(c2 + 1, c3).toFloat();
          temperature = serial_buf.substring(c3 + 1, c4).toFloat();
        }
      }
      serial_buf = "";
    } else if (c != '\r') {
      serial_buf += c;
    }
  }
  
  if (auto_mode) {
    disturbance = digitalRead(SIGNAL_PIN);
  }
  
  // LCD
  lcd.setCursor(0, 0);
  lcd.print(auto_mode ? "MODE: AUTO    " : "MODE: MANUAL  ");
  lcd.setCursor(0, 1);
  lcd.print(disturbance ? "DISTURBANCE!   " : "Normal         ");
  
  // OLED
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setCursor(0, 0);
  oled.println("GREENHOUSE MONITOR");
  oled.setCursor(0, 15);
  oled.print("X:"); oled.print(accel_x, 1);
  oled.print(" Y:"); oled.print(accel_y, 1);
  oled.setCursor(0, 28);
  oled.print("Z:"); oled.print(accel_z, 1);
  oled.setCursor(0, 41);
  oled.print("Temp: "); oled.print(temperature, 1); oled.print("C");
  
  if (disturbance) {
    oled.fillRect(0, 56, 128, 8, SSD1306_WHITE);
    oled.setTextColor(SSD1306_BLACK);
    oled.setCursor(20, 56);
    oled.println("DISTURBANCE!");
  } else {
    oled.setTextColor(SSD1306_WHITE);
    oled.setCursor(35, 56);
    oled.println("Normal");
  }
  oled.display();
  
  // Buzzer
  if (disturbance && auto_mode) {
    if (beep_count < 6 && millis() - last_beep > 200) {
      if (beep_count % 2 == 0) {
        digitalWrite(BUZZER_PIN, HIGH);
        digitalWrite(LED_PIN, HIGH);
      } else {
        digitalWrite(BUZZER_PIN, LOW);
        digitalWrite(LED_PIN, LOW);
      }
      beep_count++;
      last_beep = millis();
    }
    if (beep_count >= 6) beep_count = 0;
  } else {
    digitalWrite(BUZZER_PIN, LOW);
    digitalWrite(LED_PIN, LOW);
    beep_count = 0;
  }
  
  delay(50);
}