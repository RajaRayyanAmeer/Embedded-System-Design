#include <SPI.h>

#define DIN_PIN   23
#define CLK_PIN   18
#define CS1_PIN   5
#define CS2_PIN   17

#define REG_NOOP       0x00
#define REG_DIGIT0     0x01
#define REG_DECODEMODE 0x09
#define REG_INTENSITY  0x0A
#define REG_SCANLIMIT  0x0B
#define REG_SHUTDOWN   0x0C
#define REG_DISPTEST   0x0F

void max7219_write1(uint8_t address, uint8_t data) {
  digitalWrite(CS1_PIN, LOW);
  SPI.transfer(address);
  SPI.transfer(data);
  digitalWrite(CS1_PIN, HIGH);
}

void max7219_write2(uint8_t address, uint8_t data) {
  digitalWrite(CS2_PIN, LOW);
  SPI.transfer(address);
  SPI.transfer(data);
  digitalWrite(CS2_PIN, HIGH);
}

void initBoth() {
  pinMode(CS1_PIN, OUTPUT);
  pinMode(CS2_PIN, OUTPUT);
  digitalWrite(CS1_PIN, HIGH);
  digitalWrite(CS2_PIN, HIGH);
  SPI.begin();

 
  max7219_write1(REG_DECODEMODE, 0x00);
  max7219_write1(REG_INTENSITY,  0x08);
  max7219_write1(REG_SCANLIMIT,  0x07);
  max7219_write1(REG_SHUTDOWN,   0x01); 
  max7219_write1(REG_DISPTEST,   0x00);

  // Init matrix 2
  max7219_write2(REG_DECODEMODE, 0x00);
  max7219_write2(REG_INTENSITY,  0x08);
  max7219_write2(REG_SCANLIMIT,  0x07);
  max7219_write2(REG_SHUTDOWN,   0x01);
  max7219_write2(REG_DISPTEST,   0x00);
}

void clearAll() {
  for (int i = 0; i < 8; i++) {
    max7219_write1(REG_DIGIT0 + i, 0x00);
    max7219_write2(REG_DIGIT0 + i, 0x00);
  }
}

void setup() {
  Serial.begin(115200);
  initBoth();
  clearAll();
}

void loop() {
  for (int i = 0; i < 8; i++) {
    max7219_write1(REG_DIGIT0 + i, B10101010);
  }
  delay(1000);

  for (int i = 0; i < 8; i++) {
    max7219_write2(REG_DIGIT0 + i, B01010101);
  }
  delay(1000);

  clearAll();
  delay(500);
}