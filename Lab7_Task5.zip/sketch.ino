#include <SPI.h>

#define DIN_PIN     23
#define CLK_PIN     18
#define CS_PIN      5
#define SENSOR_PIN  34
#define RESET_BTN   25

// MAX7219 registers
#define REG_NOOP       0x00
#define REG_DIGIT0     0x01
#define REG_DECODEMODE 0x09
#define REG_INTENSITY  0x0A
#define REG_SCANLIMIT  0x0B
#define REG_SHUTDOWN   0x0C
#define REG_DISPTEST   0x0F

void max7219_write(uint8_t address, uint8_t data) {
  digitalWrite(CS_PIN, LOW);
  SPI.transfer(address);
  SPI.transfer(data);
  digitalWrite(CS_PIN, HIGH);
}

void max7219_init() {
  pinMode(CS_PIN, OUTPUT);
  digitalWrite(CS_PIN, HIGH);
  SPI.begin();
  max7219_write(REG_DECODEMODE, 0x00);  
  max7219_write(REG_INTENSITY,  0x08);  
  max7219_write(REG_SCANLIMIT,  0x07);  
  max7219_write(REG_SHUTDOWN,   0x01);  
  max7219_write(REG_DISPTEST,   0x00);  
}

void max7219_clear() {
  for (int i = 0; i < 8; i++) {
    max7219_write(REG_DIGIT0 + i, 0x00);
  }
}

void max7219_setRow(uint8_t row, uint8_t value) {
  if (row < 8) {
    max7219_write(REG_DIGIT0 + row, value);
  }
}

enum AlertLevel { NORMAL, WARNING, CRITICAL };
AlertLevel currentLevel = NORMAL;

void setup() {
  Serial.begin(115200);
  max7219_init();
  max7219_clear();
  pinMode(RESET_BTN, INPUT_PULLUP);
}

void loop() {
  int val = analogRead(SENSOR_PIN);

  if (val > 3000) {
    if (currentLevel < CRITICAL) currentLevel = CRITICAL;
  } else if (val > 1500) {
    if (currentLevel < WARNING) currentLevel = WARNING;
  }

  if (digitalRead(RESET_BTN) == LOW) {
    currentLevel = NORMAL;
    delay(200); 
  }

  max7219_clear();
  switch (currentLevel) {
    case NORMAL:
      for (int i = 0; i < 8; i++) max7219_setRow(i, B00111000);
      break;
    case WARNING:
      for (int i = 0; i < 8; i++) max7219_setRow(i, B00111100);
      break;
    case CRITICAL:
      static bool flash = false;
      flash = !flash;
      if (flash) {
        for (int i = 0; i < 8; i++) max7219_setRow(i, B01111110);
      }
      break;
  }
  delay(300);
}