#include <Wire.h>
#include <LiquidCrystal_I2C.h>

#define SENSOR_PIN 34
#define BUZZER_PIN 25

LiquidCrystal_I2C lcd(0x27, 16, 2);

String uartBuffer = "";
int vibration = 0;
int temp = 0;
unsigned long lastRead = 0;

void sensorNode() {
  int raw = analogRead(SENSOR_PIN);
  vibration = map(raw, 0, 4095, 0, 100);
  temp = map(raw, 500, 3500, 20, 80);
  uartBuffer = "VIB:" + String(vibration) + ",TEMP:" + String(temp);
}

void receiverNode() {
  if (uartBuffer.length() > 0) {
    vibration = uartBuffer.substring(4, uartBuffer.indexOf(',')).toInt();
    temp = uartBuffer.substring(uartBuffer.indexOf("TEMP:") + 5).toInt();
    uartBuffer = "";
  }
}

void updateDisplay() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Vib:");
  lcd.print(vibration);
  lcd.print("%");
  lcd.setCursor(0, 1);
  lcd.print("Temp:");
  lcd.print(temp);
  lcd.print("C");
}

void checkAlarm() {
  if (vibration > 70 || temp > 60) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(1000);
    digitalWrite(BUZZER_PIN, LOW);
  }
}

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.print("Equipment Mon.");
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  delay(1000);
}

void loop() {
  if (millis() - lastRead >= 3000) {
    lastRead = millis();
    sensorNode();
    Serial.print("Sent: ");
    Serial.println(uartBuffer);
  }
  receiverNode();
  updateDisplay();
  checkAlarm();
  delay(10);
}