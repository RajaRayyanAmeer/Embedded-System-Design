#include <Wire.h>
#include <LiquidCrystal_I2C.h>

#define SENSOR_PIN 34
#define BUZZER_PIN 25

LiquidCrystal_I2C lcd(0x27, 16, 2);

String uartBuffer = "";
int moisture = 0;
int temp = 0;
unsigned long lastRead = 0;

void sensorNode() {
  int raw = analogRead(SENSOR_PIN);
  moisture = map(raw, 0, 4095, 0, 100);
  temp = map(raw, 500, 3500, 10, 50);
  uartBuffer = "MOIST:" + String(moisture) + ",TEMP:" + String(temp);
}

void receiverNode() {
  if (uartBuffer.length() > 0) {
    int m = uartBuffer.substring(6, uartBuffer.indexOf(',')).toInt();
    int t = uartBuffer.substring(uartBuffer.indexOf("TEMP:") + 5).toInt();
    moisture = m;
    temp = t;
    uartBuffer = "";
  }
}

void updateDisplay() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Moist:");
  lcd.print(moisture);
  lcd.print("%");
  lcd.setCursor(0, 1);
  lcd.print("Temp:");
  lcd.print(temp);
  lcd.print("C");
}

void checkAlarm() {
  if (moisture < 30 || temp > 40) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(500);
    digitalWrite(BUZZER_PIN, LOW);
  }
}

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.print("Agriculture Mon.");
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  delay(1000);
}

void loop() {
  if (millis() - lastRead >= 3000) {
    lastRead = millis();
    sensorNode();
    Serial.print("Sent: ");
    Serial.println(uartBuffer);
  }
  receiverNode();
  updateDisplay();
  checkAlarm();
  delay(10);
}