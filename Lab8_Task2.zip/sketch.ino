#include <Wire.h>
#include <LiquidCrystal_I2C.h>

#define SENSOR_PIN 34
#define BUZZER_PIN 25
#define THRESHOLD 3000

LiquidCrystal_I2C lcd(0x27, 16, 2);

String uartBuffer = "";
bool alertActive = false;
unsigned long lastRead = 0;

void sensorNode() {
  int val = analogRead(SENSOR_PIN);
  if (val > THRESHOLD) {
    uartBuffer = "ALERT: High Pollution Level";
  } else {
    uartBuffer = "NORMAL";
  }
}

void receiverNode() {
  if (uartBuffer.length() > 0) {
    Serial.print("Received: ");
    Serial.println(uartBuffer);
    alertActive = uartBuffer.startsWith("ALERT");
    uartBuffer = "";
  }
}

void updateDisplay() {
  lcd.clear();
  if (alertActive) {
    lcd.print("POLLUTION ALERT!");
    digitalWrite(BUZZER_PIN, HIGH);
  } else {
    lcd.print("Air Quality OK");
    digitalWrite(BUZZER_PIN, LOW);
  }
}

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.print("Pollution Monitor");
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  delay(1000);
}

void loop() {
  if (millis() - lastRead >= 2000) {
    lastRead = millis();
    sensorNode();
    Serial.print("Sent: ");
    Serial.println(uartBuffer);
  }
  receiverNode();
  updateDisplay();
  delay(10);
}