#include <Wire.h>
#include <LiquidCrystal_I2C.h>

#define SENSOR_PIN 34
#define BUZZER_PIN 25
#define FLOOD_LVL 2500
#define FIRE_TEMP 3500

LiquidCrystal_I2C lcd(0x27, 16, 2);

String uartBuffer = "";
String alertType = "NORMAL";
unsigned long lastRead = 0;

void sensorNode() {
  int val = analogRead(SENSOR_PIN);
  if (val > FIRE_TEMP) {
    uartBuffer = "ALERT: FIRE DETECTED";
  } else if (val > FLOOD_LVL) {
    uartBuffer = "ALERT: FLOOD WARNING";
  } else {
    uartBuffer = "NORMAL";
  }
}

void receiverNode() {
  if (uartBuffer.length() > 0) {
    alertType = uartBuffer;
    uartBuffer = "";
  }
}

void updateDisplay() {
  lcd.clear();
  if (alertType.indexOf("FIRE") != -1) {
    lcd.print("FIRE ALERT!");
    digitalWrite(BUZZER_PIN, HIGH);
  } else if (alertType.indexOf("FLOOD") != -1) {
    lcd.print("FLOOD WARNING");
    digitalWrite(BUZZER_PIN, HIGH);
  } else {
    lcd.print("System Normal");
    digitalWrite(BUZZER_PIN, LOW);
  }
}

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.print("Disaster Monitor");
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  delay(1000);
}

void loop() {
  if (millis() - lastRead >= 2000) {
    lastRead = millis();
    sensorNode();
    Serial.print("Sent: ");
    Serial.println(uartBuffer);
  }
  receiverNode();
  updateDisplay();
  delay(10);
}