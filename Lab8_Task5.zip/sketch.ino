#include <Wire.h>
#include <LiquidCrystal_I2C.h>

#define SENSOR_PIN 34

LiquidCrystal_I2C lcd(0x27, 16, 2);

String uartBuffer = "";
int light = 0;
int temp = 0;
unsigned long lastRead = 0;

void sensorNode() {
  int raw = analogRead(SENSOR_PIN);
  light = map(raw, 0, 4095, 0, 100);
  temp = map(raw, 0, 4095, 15, 35);
  uartBuffer = "LIGHT:" + String(light) + ",TEMP:" + String(temp);
}

void receiverNode() {
  if (uartBuffer.length() > 0) {
    light = uartBuffer.substring(6, uartBuffer.indexOf(',')).toInt();
    temp = uartBuffer.substring(uartBuffer.indexOf("TEMP:") + 5).toInt();
    uartBuffer = "";
  }
}

void updateDisplay() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Light:");
  lcd.print(light);
  lcd.print("%");
  lcd.setCursor(0, 1);
  lcd.print("Temp:");
  lcd.print(temp);
  lcd.print("C");
}

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.print("Campus Monitor");
  delay(1000);
}

void loop() {
  if (millis() - lastRead >= 3000) {
    lastRead = millis();
    sensorNode();
    Serial.print("Sent: ");
    Serial.println(uartBuffer);
  }
  receiverNode();
  updateDisplay();
  delay(10);
}